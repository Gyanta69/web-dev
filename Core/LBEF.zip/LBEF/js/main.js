// Main JavaScript functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize any global functionality here
    console.log('Main JS loaded');
});
